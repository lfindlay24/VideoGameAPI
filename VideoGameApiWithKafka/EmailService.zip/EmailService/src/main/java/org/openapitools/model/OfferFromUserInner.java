package org.openapitools.model;



public interface OfferFromUserInner {
}
