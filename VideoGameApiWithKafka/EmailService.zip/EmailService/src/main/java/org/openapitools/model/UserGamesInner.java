package org.openapitools.model;


public interface UserGamesInner {
}
