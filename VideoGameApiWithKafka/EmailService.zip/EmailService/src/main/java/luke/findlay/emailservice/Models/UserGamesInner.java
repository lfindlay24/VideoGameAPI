package luke.findlay.emailservice.Models;


public interface UserGamesInner {
}
