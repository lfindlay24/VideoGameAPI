package luke.findlay.emailservice.Models;



public interface OfferFromUserInner {
}
